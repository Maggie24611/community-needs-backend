import express from 'express';
import { handleMessage } from './botFlow.js';

const app = express();
app.use(express.json());

// Memory to keep track of user steps
const sessions = {};

app.post("/chat", async (req, res) => {
  const incoming = req.body.message;
  const phone = req.body.phone || '919876543210';

  console.log(`User says: ${incoming}`);

  // Get existing session or start empty
  const currentState = sessions[phone] || {};

  // Run the state machine logic
  const result = await handleMessage(phone, incoming, currentState);

  // Save the updated state
  sessions[phone] = result.newSessionState;

  // Log payload if a report was generated
  if (result.reportPayload) {
    console.log("\n✅ REPORT GENERATED:", JSON.stringify(result.reportPayload, null, 2));
  }

  res.json({ reply: result.reply });
});

app.listen(3000, () => {
  console.log("🚀 Server running on http://localhost:3000");
  console.log("Use Postman to POST to /chat with { 'message': 'hi' }");
});