import { handleMessage } from './botFlow.js';

async function runConversation(label, inputs) {
  let state = {};
  console.log(`\n===== ${label} =====\n`);
  for (const msg of inputs) {
    const result = await handleMessage('919876543210', msg, state);
    console.log(`YOU:  "${msg}"`);
    console.log(`BOT:  ${result.reply}`);
    console.log('---');
    if (result.reportPayload) {
      console.log('\n✅ PAYLOAD FOR M1:');
      console.log(JSON.stringify(result.reportPayload, null, 2));
    }
    state = result.newSessionState;
  }
}

// Run tests one after another
async function main() {
  await runConversation('REPORT FLOW TEST', [
    'hi',
    '1',
    '2',
    '1',
    'Near Dharavi station',
    '30 families need water urgently',
    'YES',
  ]);

  await runConversation('VOLUNTEER FLOW TEST', [
    'hi',
    'VOLUNTEER',
    'YES',
    '7',
  ]);
}

main();